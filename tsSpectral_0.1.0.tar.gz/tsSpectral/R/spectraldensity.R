t <- function(tet1,tet2,l){
  1/(2*pi)*((1+tet1*cos(l)+tet2*cos(2*l))^2+(tet1*sin(l)+tet2*sin(2*l))^2)
}

sp.dens <- function(p, q, phi, theta, l) {
  if (p > 0 && q == 0) {
    # AR(p) process
    num <- 1
    den <- 0
    for (i in 1:p) {
      den <- den + phi[i] * exp(-1i * l * i)
    }
    result <- abs(num / (1 - den))^2
  } else if (p == 0 && q > 0) {
    # MA(q) process
    num <- 0
    den <- 1
    for (i in 1:q) {
      num <- num + theta[i] * exp(-1i * l * i)
    }
    result <- abs(1 + num)^2 / den^2
  } else {
    stop("Invalid input: either p or q must be zero")
  }
  return(result / (2 * pi))
}

plot.sp.dens <- function(p, q, phi, theta) {
  l <- seq(-pi, pi, length.out = 1000)
  y <- sapply(l, function(x) sp.dens(p, q, phi, theta, x))
  plot(l, y, type = "l", xlab = expression(lambda), ylab = "Spectral Density")
}

#' Spectral density function for AR(p) or MA(q) processes
#'
#' This function calculates the spectral density function for an AR(p) or MA(q) process.
#'
#' @param p The order of the AR process (must be zero for MA(q) processes).
#' @param q The order of the MA process (must be zero for AR(p) processes).
#' @param phi A vector of length `p` containing the coefficients of the AR process.
#' @param theta A vector of length `q` containing the coefficients of the MA process.
#' @param l The value of lambda at which to evaluate the spectral density function.
#'
#' @return The value of the spectral density function at the specified value of lambda.
#' @export
sp.dens <- function(p, q, phi, theta, l) {
  # ...
}

#' Plot spectral density function for AR(p) or MA(q) processes
#'
#' This function plots the spectral density function for an AR(p) or MA(q) process from `-pi` to `pi`.
#'
#' @param p The order of the AR process (must be zero for MA(q) processes).
#' @param q The order of the MA process (must be zero for AR(p) processes).
#' @param phi A vector of length `p` containing the coefficients of the AR process.
#' @param theta A vector of length `q` containing the coefficients of the MA process.
#'
#' @return A plot of the spectral density function from `-pi` to `pi`.
#' @export
plot.sp.dens <- function(p, q, phi, theta) {
  # ...
}
